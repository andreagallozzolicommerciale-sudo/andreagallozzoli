PUBBLICAZIONE — ANDREAGALLOZZOLI LUXURY
1. Crea un repository pubblico su GitHub chiamato andreagallozzoli.
2. Carica index.html nella radice.
3. Settings > Pages > Deploy from a branch > main > /(root) > Save.
4. Apri l'URL GitHub Pages mostrato da GitHub.

Il modulo usa mailto: apre l'app e-mail del visitatore e prepara un messaggio verso:
andreagallozzolicommerciale@gmail.com
